@extends('layouts.main')

@section('title','index')
    

@section('container')
    <div class="container mt-4">
        <div class="row">
            <div class="col-10">
                <h1 class="display-4 text-light">Laravel - Index page</h1>
            </div>
        </div>
    </div>
@endsection

