<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Hary 107</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item <?php echo e(Route::is('index') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('index')); ?>">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item <?php echo e(Route::is('features') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('features')); ?>">Features</a>
                </li>
                <li class="nav-item <?php echo e(Route::is('pricing') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('pricing')); ?>">Pricing</a>
                </li>
                <li class="nav-item <?php echo e(Route::is('mahasiswa.index') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('mahasiswa.index')); ?>">Mahasiswa</a>
                </li>
                <li class="nav-item <?php echo e(Route::is('students.index') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('students.index')); ?>">Student</a>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH D:\laragon\www\laravel-kuliah\resources\views/includes\navbar.blade.php ENDPATH**/ ?>