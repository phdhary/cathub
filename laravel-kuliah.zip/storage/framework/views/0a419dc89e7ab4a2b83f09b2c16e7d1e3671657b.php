

<?php $__env->startSection('title','index'); ?>
    

<?php $__env->startSection('container'); ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-10">
                <h1 class="display-4 text-light">Laravel - features page</h1>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts\main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel-kuliah\resources\views/pages\features.blade.php ENDPATH**/ ?>