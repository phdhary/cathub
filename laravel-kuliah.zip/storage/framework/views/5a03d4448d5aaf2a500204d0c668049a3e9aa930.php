

<?php $__env->startSection('title', 'Daftar Mahasiswa Baru'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8"> </div>
        <div class="col-md-4">
            <form action="/search" method="get">
                <div class="input-group mt-4"> <input type="search" name="search" class="form-control"> <span
                        class="input-group-prepend"> <button type="submit" class="btn btn-success">Search</button>
                    </span> </div>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-6 text-light">
            <h1 class="mt-10">Daftar Mahasiswa Baru</h1>

            <a href="/students/create" class="btn btn-primary my-3">Tambah Data</a>
            <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>

            <ul class="list-group">
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item d-flex justify-content-between align-items-center text-dark">
                    <?php echo e($student -> name); ?>

                    <a href="/students/<?php echo e($student -> id); ?>" class="badge badge-info">details</a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel-kuliah\resources\views/pages/students/index.blade.php ENDPATH**/ ?>