

<?php $__env->startSection('title', 'Tambah Data Mahasiswa Baru'); ?>

<?php $__env->startSection('container'); ?>
<div class="col-6 text-light">
    <h1 class="mt-10">Tambah Data Mahasiswa Baru</h1>

    <form action="/students/store" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Nama</label>
            <input type="text" name="name" id="name" class="form-control" placeholder="Masukkan Nama">
        </div>
        <div class="form-group">
            <label for="nama">NIM</label>
            <input type="text" name="nim" id="nim" class="form-control" placeholder="Masukkan NIM">
        </div>
        <div class="form-group">
            <label for="nama">Email</label>
            <input type="text" name="email" id="email" class="form-control" placeholder="Masukkan Email">
        </div>
        <div class="form-group">
            <label for="nama">Jurusan</label>
            <input type="text" name="jurusan" id="jurusan" class="form-control" placeholder="Masukkan Jurusan">
        </div>
        <button type="submit" class="btn btn-primary">Simpan Data</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel-kuliah\resources\views/pages/students/create.blade.php ENDPATH**/ ?>